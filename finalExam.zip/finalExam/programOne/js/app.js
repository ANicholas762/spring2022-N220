let transport = ["cars", "bikes", "van", "truck", "velocipedes"];
    // let arraySplit = transport.slice(1);
    console.log(transport);

    // function to loop through array and remove index
function arr() {
    forEach(transport == remove) 
        if(transport == "cars") {
            unset(transport);
        }
    }


// displays the new array without the first element
output.innerHTML = transport;
